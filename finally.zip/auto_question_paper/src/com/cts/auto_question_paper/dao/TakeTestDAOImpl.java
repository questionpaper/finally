package com.cts.auto_question_paper.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.auto_question_paper.bean.Marks;
import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.util.DBUtils;

public class TakeTestDAOImpl implements TakeTestDAO{

	@Override
	public List<Question> setPaper(String a, String b) {
		// TODO Auto-generated method stub
		
		System.out.println(a+b);
		
		Connection connection = null;
		String query = "select * from question where subject_name = ? and exam_id = ? ";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, a);
			preparedStatement.setString(2, b);
		
			resultSet = preparedStatement.executeQuery();
			List<Question> l_ques = new ArrayList<>();
			
			/*ResultSet resultSet=statement.executeQuery(sql);
			while(resultSet.next()){
				int id=resultSet.getInt("id");
				String name=resultSet.getString("name");
				String discription=resultSet.getString("discription");
				String category=resultSet.getString("category");
				float price=resultSet.getFloat("price");
				Product prod=new Product(id,name,discription,category,price);
				listProduct.add(prod);	*/
			Question question = null;
			if(resultSet.next()) {
				String question1 = resultSet.getString("question");
				String opA = resultSet.getString("op1");
				String opB = resultSet.getString("op2");
				String opC = resultSet.getString("op3");
				String opD = resultSet.getString("op4");
				String ans = resultSet.getString("ans");

				String subject_name = resultSet.getString("subject_name");
				String exam_id = resultSet.getString("exam_id");
				question = new Question(question1,opA,opB,opC,opD,ans,subject_name,exam_id);
				System.out.println(question);
				l_ques.add(question);
				System.out.println("Retrieval success" + question1 + opA + opB+ opC + opD + ans);
			}				return l_ques;
}
			
			
		
	
	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("tupple nopt found");
			return null;
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
	
	}

	@Override
	public List<Marks> viewAllScores() {
		Connection connection = null;
		String query = "select * from marks";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			
		
			resultSet = preparedStatement.executeQuery();
			List<Marks> l_mark = new ArrayList<>();
			
			/*ResultSet resultSet=statement.executeQuery(sql);
			while(resultSet.next()){
				int id=resultSet.getInt("id");
				String name=resultSet.getString("name");
				String discription=resultSet.getString("discription");
				String category=resultSet.getString("category");
				float price=resultSet.getFloat("price");
				Product prod=new Product(id,name,discription,category,price);
				listProduct.add(prod);	*/
			Marks marks = null;
			if(resultSet.next()) {
				String student_id = resultSet.getString("student_id");
				String marks1 = resultSet.getString("marks");
				
				marks = new Marks(student_id,marks1);
				System.out.println(marks);
				l_mark.add(marks);
			//	System.out.println("Retrieval success" + question1 + opA + opB+ opC + opD + ans);
			}				return l_mark;
}
			
			
		
	
	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("tupple nopt found");
			return null;
		}
		finally {
			DBUtils.closeConnection(connection);
		}	}

	@Override
	public List<Marks> userAllScores(String a) {
		// TODO Auto-generated method stub
		Connection connection = null;
		String query = "select * from marks where student_id=?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, a);

		
			resultSet = preparedStatement.executeQuery();
			List<Marks> l_mark = new ArrayList<>();
			
			/*ResultSet resultSet=statement.executeQuery(sql);
			while(resultSet.next()){
				int id=resultSet.getInt("id");
				String name=resultSet.getString("name");
				String discription=resultSet.getString("discription");
				String category=resultSet.getString("category");
				float price=resultSet.getFloat("price");
				Product prod=new Product(id,name,discription,category,price);
				listProduct.add(prod);	*/
			Marks marks = null;
			if(resultSet.next()) {
				String student_id = resultSet.getString("student_id");
				String marks1 = resultSet.getString("marks");
				
				marks = new Marks(student_id,marks1);
				System.out.println(marks);
				l_mark.add(marks);
			//	System.out.println("Retrieval success" + question1 + opA + opB+ opC + opD + ans);
			}				return l_mark;
}
			
			
		
	
	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("tupple nopt found");
			return null;
		}
		finally {
			DBUtils.closeConnection(connection);
		}		}

}
