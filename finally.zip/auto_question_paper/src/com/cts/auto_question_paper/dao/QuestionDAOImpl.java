package com.cts.auto_question_paper.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.util.DBUtils;

public class QuestionDAOImpl implements QuestionDAO {
	Question question = new Question();
	private Connection con;
	
	
	@Override
	public List<Question> getAllQuestion() {
		
		List<Question> questions = new ArrayList<Question>();
		PreparedStatement preparedStatement=null;
		String getString ="Select * from question";
	
		ResultSet resultSet= null;
		Question question = null;
		
		try {
			con = DBUtils.getConnection();
			preparedStatement = con.prepareStatement(getString);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				
				String question1 = resultSet.getString("question");
				String option1= resultSet.getString("option1");
				String option2 = resultSet.getString("option2");
				String option3 = resultSet.getString("option3");
				String option4 = resultSet.getString("option4");
				String ans = resultSet.getString("ans");
				
				question = new Question(question1,option1,option2,option3,option4,ans,"1","1");
			
				questions.add(question);
			}
			return questions;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			DBUtils.closeConnection(con);
		}
		
		return null;
		
	}


	@Override
	public String addQuestion(Question question)
	{
	
		Connection connection = null;
		String query = "insert into question values (?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String question1=question.getQuestion();
        String option1=question.getOption1();
        String option2=question.getOption2();
        String option3=question.getOption3();
        String option4=question.getOption4();
        String ans =question.getAns();
        String subject_name = question.getSubject_name();
        String exam_id = question.getExam_id();
      
         try
         {
                connection = DBUtils.getConnection();
            	
          preparedStatement = connection.prepareStatement(query); // generates sql query
   
      	preparedStatement.setString(1, question1);
      	preparedStatement.setString(2, option1);
      	preparedStatement.setString(3, option2);
      	preparedStatement.setString(4, option3);
      	preparedStatement.setString(5, option4);
      	preparedStatement.setString(6, ans);
      	preparedStatement.setString(7, subject_name);
      	preparedStatement.setString(8, exam_id);

      
  
       int i= preparedStatement.executeUpdate();
   		System.out.println("14");
                if (i!=0)  //Just to ensure data has been inserted into the database
                return "Tupple Inserted"; 
    
         }
         
         catch(SQLException e)
         {
                e.printStackTrace();
                return "Tupple Not Inserted";
         }
		return "Transaction Not Sucessful";	}



}
