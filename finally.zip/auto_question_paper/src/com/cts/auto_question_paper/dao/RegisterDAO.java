package com.cts.auto_question_paper.dao;


import com.cts.auto_question_paper.bean.RegisterBean;

public interface RegisterDAO {
	public boolean registerUser(RegisterBean bean);
	public String insertScore(String user,String b,String c,String d);

}
