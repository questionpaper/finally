package com.cts.auto_question_paper.dao;

import com.cts.auto_question_paper.bean.Admin;
import com.cts.auto_question_paper.bean.LoginBean;

public interface LoginDAO {
	
	public boolean validateUser(LoginBean bean);
	public boolean validateAdmin(Admin admin);

}
