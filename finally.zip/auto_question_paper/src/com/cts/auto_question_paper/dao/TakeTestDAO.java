package com.cts.auto_question_paper.dao;

import java.util.List;

import com.cts.auto_question_paper.bean.Marks;
import com.cts.auto_question_paper.bean.Question;

public interface TakeTestDAO {
	 public List<Question> setPaper(String a, String b);
	 public List<Marks> viewAllScores();
	 public List<Marks> userAllScores(String a);

}
