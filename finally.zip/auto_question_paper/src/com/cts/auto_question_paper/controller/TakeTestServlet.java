package com.cts.auto_question_paper.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.auto_question_paper.bean.LoginBean;
import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.service.LoginService;
import com.cts.auto_question_paper.service.LoginServiceImpl;
import com.cts.auto_question_paper.service.TakeTestService;
import com.cts.auto_question_paper.service.TakeTestServiceImpl;

public class TakeTestServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	TakeTestService takeTestService  = new TakeTestServiceImpl();

	public TakeTestServlet()
	{
		super();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ExamId = request.getParameter("Examid");
		String Subject_Names= request.getParameter("Subjectnames");
		
		List<Question> questions = takeTestService.setPaper(Subject_Names,ExamId);
		request.setAttribute("subject_name", Subject_Names);
		request.setAttribute("exam_id", ExamId);

		System.out.println("Retuned from DAO");
	    request.setAttribute("question", questions);

		RequestDispatcher dispatcher = null;
		
			dispatcher = request.getRequestDispatcher("showPaper.jsp");
			dispatcher.forward(request, response);
		
		}
		
	
	}

