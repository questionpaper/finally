package com.cts.auto_question_paper.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.auto_question_paper.service.LoginService;
import com.cts.auto_question_paper.service.LoginServiceImpl;
import com.cts.auto_question_paper.service.RegisterService;
import com.cts.auto_question_paper.service.RegisterServiceImpl;

public class CalculateScoreServlet extends HttpServlet {
	public CalculateScoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	RegisterService registerService = new RegisterServiceImpl();

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = null;

	String datafromdiv=request.getParameter("demo");

	System.out.println(datafromdiv);
    request.setAttribute("score", datafromdiv);
   String user = (String)request.getAttribute("user");
   // String user ="Student1";
    System.out.println("user");
    String subject_name = (String)request.getAttribute("subject_name");
    String exam_id = (String)request.getAttribute("exam_id");

	dispatcher = request.getRequestDispatcher("ShowScore.jsp");
	registerService.insertScore(user,datafromdiv,subject_name,exam_id);
	dispatcher.forward(request, response);
	
	
}}
