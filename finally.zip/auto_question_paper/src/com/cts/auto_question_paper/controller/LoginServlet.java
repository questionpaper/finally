package com.cts.auto_question_paper.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.auto_question_paper.bean.LoginBean;
import com.cts.auto_question_paper.service.LoginService;
import com.cts.auto_question_paper.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	LoginService loginService = new LoginServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userId = request.getParameter("username");
		String password= request.getParameter("password");
		LoginBean login = new LoginBean();
		login.setStudentId(userId);
		login.setPassword(password);
		request.setAttribute("user", userId);
	String user= (String)request.getAttribute("user");
		RequestDispatcher dispatcher = null;
		//RequestDispatcher rd = null;
		HttpSession session = request.getSession();
	      session.setAttribute("user",user );
		boolean b = loginService.validateUser(login);
		System.out.println(b);
		if(loginService.validateUser(login))
		{
			System.out.println("true");
			dispatcher = request.getRequestDispatcher("StudentChoice.jsp");
			//rd = request.getRequestDispatcher("StudentHistoryServlet.java");

			dispatcher.forward(request, response);
		//	rd.forward(request, response);

		}
		
		else
			
		{
			System.out.println("User not found. Please Register");
			dispatcher=request.getRequestDispatcher("register.jsp");
			dispatcher.forward(request, response);
		}
	}

}
