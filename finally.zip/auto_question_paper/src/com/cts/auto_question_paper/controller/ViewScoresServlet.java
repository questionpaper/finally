package com.cts.auto_question_paper.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.auto_question_paper.bean.Marks;
import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.service.TakeTestService;
import com.cts.auto_question_paper.service.TakeTestServiceImpl;

public class ViewScoresServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	TakeTestService takeTestService  = new TakeTestServiceImpl();

	public ViewScoresServlet()
	{
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		List<Marks> marks = takeTestService.viewAllScores();
		System.out.println("Retuned from DAO");

		RequestDispatcher dispatcher = null;
	    request.setAttribute("marks", marks);

			dispatcher = request.getRequestDispatcher("showAllScores.jsp");
			dispatcher.forward(request, response);
		
		}
		
	
	
}
