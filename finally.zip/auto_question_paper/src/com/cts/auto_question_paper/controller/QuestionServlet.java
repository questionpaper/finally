package com.cts.auto_question_paper.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.service.QuestionService;
import com.cts.auto_question_paper.service.QuestionServiceImpl;

/**
 * Servlet implementation class QuestionServlet
 */
public class QuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	QuestionService questionService = new QuestionServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */

    public QuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		System.out.println("0");
		Question question1 = new Question();
		System.out.println("1");
		String question = request.getParameter("question");
		String option1 = request.getParameter("option1");
		String option2 = request.getParameter("option2");
		String option3 = request.getParameter("option3");
		String option4 = request.getParameter("option4");
		String ans = request.getParameter("ans");
		String subject_name = request.getParameter("subject_name");
		String exam_id = request.getParameter("exam_id");

		
		question1.setQuestion(question);
		question1.setOption1(option1);
		question1.setOption2(option2);
		question1.setOption3(option3);
		question1.setOption4(option4);
		question1.setAns(ans);
		question1.setExam_id(exam_id);
		question1.setSubject_name(subject_name);
		System.out.println(question1.toString());
		
		
		questionService.addQuestion(question1);
		RequestDispatcher dispatcher = null;

		dispatcher=request.getRequestDispatcher("SetPaper.jsp");
		dispatcher.forward(request, response);
		
//		if(questionService.addQuestion(question1) == 1)
//		{
//			request.getRequestDispatcher("submitQuestion.jsp").forward(request, response);
////            request.setAttribute("addResourceMsg", "Resource Added");
////            session.setAttribute("addResourceMsg", "Resource Added");
//
//		}
//		
//		else
//		{
//			request.getRequestDispatcher("submitResources.jsp").forward(request, response);
////            request.setAttribute("addResourceMsg", "Resource Not Added");
////            session.setAttribute("addResourceMsg", "Resource Added");
//
//		}
	}

}
	

