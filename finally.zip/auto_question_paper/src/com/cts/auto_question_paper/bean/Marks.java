package com.cts.auto_question_paper.bean;

public class Marks {
	private String student_id;
	private String marks;
	private String subject_name;
	private String exam_id;
	public Marks()
	{}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	
	public Marks(String student_id, String marks) {
		super();
		this.student_id = student_id;
		this.marks = marks;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public String getExam_id() {
		return exam_id;
	}
	public void setExam_id(String exam_id) {
		this.exam_id = exam_id;
	}
	@Override
	public String toString() {
		return "Marks [student_id=" + student_id + ", marks=" + marks + ", subject_name=" + subject_name + ", exam_id="
				+ exam_id + "]";
	}
}
