package com.cts.auto_question_paper.bean;

public class LoginBean {
	
	private String studentId;
	private String password;
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public LoginBean() {
		super();
	}
	public LoginBean(String studentId, String password) {
		super();
		this.studentId = studentId;
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginBean [studentId=" + studentId + ", password=" + password + "]";
	}

	
	
	
	
	

}
