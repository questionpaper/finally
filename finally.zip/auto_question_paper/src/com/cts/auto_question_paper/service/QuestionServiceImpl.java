package com.cts.auto_question_paper.service;


import java.util.List;

import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.dao.QuestionDAOImpl;
import com.cts.auto_question_paper.dao.QuestionDAO;


public class QuestionServiceImpl implements QuestionService {

	QuestionDAO questionDAO = new QuestionDAOImpl(); 
	
	@Override
	public String addQuestion(Question question) {
		// TODO Auto-generated method stub
		System.out.println("5");
		System.out.println(question);
		return questionDAO.addQuestion(question);
	}
	
	@Override
	public List<Question> getAllQuestion() {
		// TODO Auto-generated method stub
		return questionDAO.getAllQuestion();
	}
}



