package com.cts.auto_question_paper.service;

import com.cts.auto_question_paper.bean.Admin;
import com.cts.auto_question_paper.bean.LoginBean;
import com.cts.auto_question_paper.dao.LoginDAO;
import com.cts.auto_question_paper.dao.LoginDAOImpl;

public class LoginServiceImpl implements LoginService{

	LoginDAO loginDAO = new LoginDAOImpl();
	public boolean validateUser(LoginBean login) {
		// TODO Auto-generated method stub
		return loginDAO.validateUser(login);
	}
	@Override
	public boolean validateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		System.out.println("validate service");
		return loginDAO.validateAdmin(admin);
	}

}
 