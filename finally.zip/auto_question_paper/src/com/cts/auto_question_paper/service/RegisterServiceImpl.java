package com.cts.auto_question_paper.service;


import com.cts.auto_question_paper.bean.RegisterBean;
import com.cts.auto_question_paper.dao.RegisterDAOImpl;
import com.cts.auto_question_paper.dao.RegisterDAO;



	public class RegisterServiceImpl implements RegisterService
{

		RegisterDAO registerDAO = new RegisterDAOImpl();
		public boolean registerUser(RegisterBean bean) {
			return registerDAO.registerUser(bean);
		}
		@Override
		public String insertScore(String user, String b, String c, String d) {
			// TODO Auto-generated method stub
			return registerDAO.insertScore(user, b,c,d);
		}
	}
