package com.cts.auto_question_paper.service;

import java.util.List;

import com.cts.auto_question_paper.bean.Marks;
import com.cts.auto_question_paper.bean.Question;

public interface TakeTestService {
 public List<Question> setPaper(String a, String b);
 
 public List<Marks> viewAllScores();
 public List<Marks> userAllScores(String a );

}
