package com.cts.auto_question_paper.service;

import java.util.List;

import com.cts.auto_question_paper.bean.Marks;
import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.bean.RegisterBean;
import com.cts.auto_question_paper.dao.RegisterDAO;
import com.cts.auto_question_paper.dao.RegisterDAOImpl;
import com.cts.auto_question_paper.dao.TakeTestDAO;
import com.cts.auto_question_paper.dao.TakeTestDAOImpl;

public class TakeTestServiceImpl implements TakeTestService{

	
	
	TakeTestDAO takeTestDAO = new TakeTestDAOImpl();
	@Override
	public List<Question> setPaper(String a, String b) {
		// TODO Auto-generated method stub
		return takeTestDAO.setPaper(a,b);
	}
	@Override
	public List<Marks> viewAllScores() {
		// TODO Auto-generated method stub
		return takeTestDAO.viewAllScores();

	}
	public List<Marks> userAllScores(String a) {
		// TODO Auto-generated method stub
		return takeTestDAO.userAllScores(a);

	}

}
